from flight import Flight
from collections import deque

class Planner:
    def __init__(self, flights):
        """The Planner

        Args:
            flights (List[Flight]): A list of information of all the flights (objects of class Flight)
        """
        self.inflights=[]
        self.outflights=[]
        min=float('inf')
        max=float("-inf")
        self.m=len(flights)

        for i in flights:
            if i.start_city<min:
                min=i.start_city
            if i.end_city>max:
                max=i.end_city
            
        no_of_cities=max-min+1
        for i in range(no_of_cities):
            self.inflights.append([])
            self.outflights.append([])


        for i in flights:
            self.inflights[i.end_city].append(i)
            self.outflights[i.start_city].append(i)

        

   
    # def least_flights_ealiest_route(self, start_city, end_city, t1, t2):
    #     """
    #     Return List[Flight]: A route from start_city to end_city, which departs after t1 (>= t1) and
    #     arrives before t2 (<= t2) satisfying:
    #     - The route has the least number of flights
    #     - Within routes with the same number of flights, arrives the earliest.
    #     """

    #     start_index = start_city
    #     end_index = end_city
    #     if start_city == end_city:
    #         return []

    #     # If there is a direct flight from start_city to end_city
    #     for flight in self.outflights[start_index]:
    #         if flight.end_city == end_index and flight.departure_time >= t1 and flight.arrival_time <= t2:
    #             return [flight]  # Direct flight, return it as the best route

    #     # Queue for BFS: (current city index, num_flights, arrival_time, route)
    #     queue = Queue()
    #     queue.enqueue((start_index, 0, t1, []))  # Initial state
    #     best_arrival = [None] *len(self.outflight)

    #     while not queue.is_empty():
    #         current_index, num_flights, arrival_time, route = queue.dequeue()

    #         # Check if we reached the destination city
    #         if current_index == end_index:
    #             if best_arrival[end_index] is None or num_flights < best_arrival[end_index][0] or \
    #             (num_flights == best_arrival[end_index][0] and arrival_time < best_arrival[end_index][1]):
    #                 best_arrival[end_index] = (num_flights, arrival_time, route)
    #             continue

    #         # Explore outgoing flights from the current city
    #         for flight in self.outflights[current_index]:
    #             next_index = flight.end_city

    #             # For the first flight, we do not need to check the 20-minute constraint
    #             if num_flights == 0:
    #                 if flight.departure_time >= t1 and flight.arrival_time <= t2:
    #                     new_route = route + [flight]
    #                     if best_arrival[next_index] is None or \
    #                     (num_flights + 1 < best_arrival[next_index][0]) or \
    #                     (num_flights + 1 == best_arrival[next_index][0] and flight.arrival_time < best_arrival[next_index][1]):
    #                         best_arrival[next_index] = (num_flights + 1, flight.arrival_time, new_route)
    #                         queue.enqueue((next_index, num_flights + 1, flight.arrival_time, new_route))
    #             else:
    #                 # For connecting flights, apply the 20-minute constraint
    #                 if flight.departure_time >= arrival_time + 20 and flight.arrival_time <= t2:
    #                     new_route = route + [flight]
    #                     if best_arrival[next_index] is None or \
    #                     (num_flights + 1 < best_arrival[next_index][0]) or \
    #                     (num_flights + 1 == best_arrival[next_index][0] and flight.arrival_time < best_arrival[next_index][1]):
    #                         best_arrival[next_index] = (num_flights + 1, flight.arrival_time, new_route)
    #                         queue.enqueue((next_index, num_flights + 1, flight.arrival_time, new_route))

    #     return best_arrival[end_index][2] if best_arrival[end_index] is not None else []

    def least_flights_ealiest_route(self, start_city, end_city, t1, t2):
        """
        Return List[Flight]: A route from start_city to end_city, which departs after t1 (>= t1) and
        arrives before t2 (<= t2) satisfying:
        - The route has the least number of flights
        - Within routes with the same number of flights, arrives the earliest.
        """
        if start_city == end_city:
            return []

        # BFS queue: (current city, number of flights, arrival time, route)
        queue = Queue()
        queue.enqueue((start_city, 0, t1, []))  # Start with the starting city, no flights, and time t1

        # To track the best route to each city (number of flights, arrival time, route)
        best_route = [None] * len(self.outflights)

        while not queue.is_empty():
            current_city, num_flights, arrival_time, route = queue.dequeue()

            # If we reached the destination city, check if this is the best route
            if current_city == end_city:
                if (
                    best_route[end_city] is None or
                    num_flights < best_route[end_city][0] or
                    (num_flights == best_route[end_city][0] and arrival_time < best_route[end_city][1])
                ):
                    best_route[end_city] = (num_flights, arrival_time, route)
                continue

            # Explore outgoing flights from the current city
            for flight in self.outflights[current_city]:
                next_city = flight.end_city

                # Check departure and arrival time constraints
                if num_flights == 0:  # First flight
                    if flight.departure_time >= t1 and flight.arrival_time <= t2:
                        new_route = route + [flight]
                        if (
                            best_route[next_city] is None or
                            (num_flights + 1 < best_route[next_city][0]) or
                            (num_flights + 1 == best_route[next_city][0] and flight.arrival_time < best_route[next_city][1])
                        ):
                            best_route[next_city] = (num_flights + 1, flight.arrival_time, new_route)
                            queue.enqueue((next_city, num_flights + 1, flight.arrival_time, new_route))
                else:  # Connecting flights
                    if flight.departure_time >= arrival_time + 20 and flight.arrival_time <= t2:
                        new_route = route + [flight]
                        if (
                            best_route[next_city] is None or
                            (num_flights + 1 < best_route[next_city][0]) or
                            (num_flights + 1 == best_route[next_city][0] and flight.arrival_time < best_route[next_city][1])
                        ):
                            best_route[next_city] = (num_flights + 1, flight.arrival_time, new_route)
                            queue.enqueue((next_city, num_flights + 1, flight.arrival_time, new_route))

        return best_route[end_city][2] if best_route[end_city] is not None else []

    
    
        
        
        
        
        
        
        # while not queue.is_empty():
        #     current_index, num_flights, arrival_time, route = queue.dequeue()

        #     # Check if we reached the destination city
        #     if current_index == end_index:
        #         print(current_index)
        #         if best_arrival[end_index] is None or num_flights < best_arrival[end_index][0] or \
        #            (num_flights == best_arrival[end_index][0] and arrival_time < best_arrival[end_index][1]):
        #             best_arrival[end_index] = (num_flights, arrival_time, route)
        #         continue

        #     # Explore outgoing flights from the current city
        #     for flight in self.outflights[current_index]:
        #         next_index = flight.end_city

        #         # For the first flight, we do not need to check the 20-minute constraint
        #         if num_flights == 0:
        #             if flight.departure_time >= t1 and flight.arrival_time <= t2:
        #                 new_route = route + [flight]
        #                 if best_arrival[next_index] is None or \
        #                    (num_flights + 1 < best_arrival[next_index][0]) or \
        #                    (num_flights + 1 == best_arrival[next_index][0] and flight.arrival_time < best_arrival[next_index][1]):
        #                     best_arrival[next_index] = (num_flights + 1, flight.arrival_time, new_route)
        #                     queue.enqueue((next_index, num_flights + 1, flight.arrival_time, new_route))  #best arrival time ko hi daal denge ya is se hi output le lenge
        #         else:
        #             # For connecting flights, apply the 20-minute constraint
        #             if flight.departure_time >= arrival_time + 20 and flight.arrival_time <= t2:
        #                 new_route = route + [flight]
        #                 if best_arrival[next_index] is None or \
        #                    (num_flights + 1 < best_arrival[next_index][0]) or \
        #                    (num_flights + 1 == best_arrival[next_index][0] and flight.arrival_time < best_arrival[next_index][1]):
        #                     best_arrival[next_index] = (num_flights + 1, flight.arrival_time, new_route)
        #                     queue.enqueue((next_index, num_flights + 1, flight.arrival_time, new_route))

        # return best_arrival[end_index][2] if best_arrival[end_index] is not None else []
    
    # def cheapest_route(self, start_city, end_city, t1, t2):
    #     """
    #     Return List[Flight]: A route from start_city to end_city, which departs after t1 (>= t1) and
    #     arrives before t2 (<=) satisfying: 
    #     The route is a cheapest route
    #     """
    #     start=start_city
    #     end=end_city
    #     heap=Heap(fare,[])
    #     daddy=[None]*self.m
    #     cost=[float("inf")]*self.m
    #     last=None
    #     # print(daddy)

    #     for i in self.outflights[start]:
    #         heap.insert(i)
    #         cost[i.flight_no]=i.fare
    #     last_fare=float("inf")
    #     while not heap.is_empty():
    #         curr_flight = heap.extract()
    #         # print(curr_flight)

    #         if curr_flight is None:  # Handle edge case
    #             # print("Extracted None flight unexpectedly. Breaking loop.")
    #             break

    #         curr_fare = curr_flight.fare

    #         if curr_flight.end_city == end_city:
    #             # print("end")
    #             if curr_fare < last_fare:
    #                 cost[curr_flight.flight_no] = curr_fare
    #                 last = curr_flight
    #                 last_fare=curr_fare
    #             continue

    #         for i in self.outflights[curr_flight.end_city]:
    #             # print("cheeti")
    #             if i.departure_time >= curr_flight.arrival_time + 20 and i.arrival_time <= t2:
    #                 # print("bro")
                    
    #                 if curr_fare + i.fare < cost[i.flight_no]:
    #                     # print("allah",ij)
                
    #                     heap.insert(i)
    #                     cost[i.flight_no] = curr_fare + i.fare
    #                     daddy[i.flight_no] = curr_flight
    #         # print(daddy)
    #     if last is None:
    #         return []
    #     else:
    #         route = [last]
    #         curr= last
    #         while daddy[curr.flight_no] is not None:
    #             route.append(daddy[curr.flight_no])
    #             curr = daddy[curr.flight_no]

    #         return route[::-1]

    # def cheapest_route(self, start_city, end_city, t1, t2):
    #     """
    #     Return List[Flight]: A route from start_city to end_city, which departs after t1 (>= t1) and
    #     arrives before t2 (<=) satisfying: 
    #     The route is a cheapest route
    #     """
    #     start = start_city
    #     end = end_city
    #     heap = Heap(fare, [])
    #     daddy = [None] * self.m
    #     cost = [float("inf")] * self.m
    #     visited = [False] * self.m  # Track if a flight has been processed
    #     last = None

    #     # Add all outgoing flights from start city to heap
    #     for i in self.outflights[start]:
    #         if i.departure_time >= t1 and i.arrival_time <= t2:
    #             heap.insert(i)
    #             cost[i.flight_no] = i.fare

    #     last_fare = float("inf")

    #     while not heap.is_empty():
    #         curr_flight = heap.extract()

    #         if curr_flight is None:
    #             break

    #         if visited[curr_flight.flight_no]:  # Skip already visited flights
    #             continue

    #         visited[curr_flight.flight_no] = True  # Mark current flight as visited
    #         curr_fare = curr_flight.fare

    #         # Check if the end city is reached
    #         if curr_flight.end_city == end_city:
    #             if curr_fare < last_fare:
    #                 last = curr_flight
    #                 last_fare = curr_fare
    #             continue

    #         # Process outgoing flights from the current flight's end city
    #         for i in self.outflights[curr_flight.end_city]:
    #             if (
    #                 i.departure_time >= curr_flight.arrival_time + 20
    #                 and i.arrival_time <= t2
    #                 and not visited[i.flight_no]
    #             ):
    #                 new_fare = curr_fare + i.fare
    #                 if new_fare < cost[i.flight_no]:
    #                     heap.insert(i)
    #                     cost[i.flight_no] = new_fare
    #                     daddy[i.flight_no] = curr_flight

    #     # Reconstruct the route
    #     if last is None:
    #         return []
    #     else:
    #         route = [last]
    #         curr = last
    #         while daddy[curr.flight_no] is not None:
    #             route.append(daddy[curr.flight_no])
    #             curr = daddy[curr.flight_no]

    #         return route[::-1]



    def cheapest_route(self, start_city, end_city, t1, t2):
        """
        Return List[Flight]: A route from start_city to end_city, which departs after t1 (>= t1) and
        arrives before t2 (<=) satisfying: 
        The route is a cheapest route
        """
        if start_city==end_city:
            return []
        start = start_city
        
        heap = Heap(miya, [])
        # heap= Heap(fare,[])
        daddy = [None] * self.m
        cost = [float("inf")] *(self.m)
        visited = [False] *(self.m)
        last = None

        # Add all outgoing flights from start city to heap
        for flight in self.outflights[start]:
            if flight.departure_time >= t1 and flight.arrival_time <= t2:
                heap.insert((flight.fare, flight))
                cost[flight.flight_no] = flight.fare

        last_fare = float("inf")

        while not heap.is_empty():
            curr_fare, curr_flight = heap.extract()
            # print(curr_flight.flight_no)
            if visited[curr_flight.flight_no]:
                continue

            visited[curr_flight.flight_no] = True

            

            # Check if the end city is reached
            if curr_flight.end_city == end_city:
                # print(curr_flight)
                if curr_fare < last_fare:
                    last = curr_flight
                    last_fare = curr_fare
                continue
           

            # Process outgoing flights from the current flight's end city
            for i in self.outflights[curr_flight.end_city]:
                if (
                    i.departure_time >= curr_flight.arrival_time + 20
                    and i.arrival_time <= t2
                    and not visited[i.flight_no]
                ):
                    new_fare = curr_fare + i.fare
                    if new_fare < cost[i.flight_no]:
                        heap.insert((new_fare, i))
                        # print("bro")
                        cost[i.flight_no] = new_fare
                        daddy[i.flight_no] = curr_flight

        # the route
        if last is None:
            return []
        else:
            route = [last]
            curr = last
            while daddy[curr.flight_no] is not None:
                route.append(daddy[curr.flight_no])
                curr = daddy[curr.flight_no]

            return list(reversed(route))

        
            
        
   
    #     for i in self.outflights[start]:
    #         heap.insert(((0,i.fare),i))
    #         cost[i.flight_no]=(0,i.fare)
    #     last_fare=(float("inf"),float("inf"))
    #     while not heap.is_empty():
    #         info,curr_flight = heap.extract()
    #         # print(curr_flight)
    #         no_flight=info[0]
    #         curr_fare=info[1]

    #         if curr_flight is None:  # Handle edge case
    #             # print("Extracted None flight unexpectedly. Breaking loop.")
    #             break

            

    #         if curr_flight.end_city == end_city:
    #             # print("end")
    #             if info < last_fare:
    #                 cost[curr_flight.flight_no] = (no_flight+1,curr_fare)
    #                 last = curr_flight
    #                 last_fare=info

    #             continue

  

    def least_flights_cheapest_route(self, start_city, end_city, t1, t2):
        """
        Return List[Flight]: A route from start_city to end_city, which departs after t1 (>= t1) and
        arrives before t2 (<= t2) satisfying:
        - The route has the least number of flights
        - Within routes with the same number of flights, is the cheapest
        """
        if start_city == end_city:
            return []

        start = start_city
        end = end_city

        heap = Heap(miya, [])  # Assuming `Heap` is a min-heap implementation
        daddy = [None] * (self.m)  # Tracks the parent flight for reconstructing the path
        cost = [(float("inf"), float("inf"))] * (self.m)  # (number of flights, fare)
        visited = [False] * (self.m)  # To track visited flights

        # Add all outgoing flights from the start city to the heap
        for flight in self.outflights[start]:
            if flight.departure_time >= t1 and flight.arrival_time <= t2:
                heap.insert(((0, flight.fare), flight))
                cost[flight.flight_no] = (0, flight.fare)

        last = None
        last_fare = (float("inf"), float("inf"))

        while not heap.is_empty():
            info, curr_flight = heap.extract()
            no_flight, curr_fare = info
            if visited[curr_flight.flight_no]:
                continue

            visited[curr_flight.flight_no] = True

            if curr_flight is None:
                continue

            # Check if we've reached the destination city
            if curr_flight.end_city == end:
                if info < last_fare:
                    cost[curr_flight.flight_no] = (no_flight + 1, curr_fare)
                    last = curr_flight
                    last_fare = info
                continue

            # Process outgoing flights from the current flight's end city
            for i in self.outflights[curr_flight.end_city]:
                if (
                    i.departure_time >= curr_flight.arrival_time + 20
                    and i.arrival_time <= t2
                ):
                    new_fare = curr_fare + i.fare
                    new_info = (no_flight + 1, new_fare)
                    if new_info < cost[i.flight_no]:
                        heap.insert((new_info, i))
                        cost[i.flight_no] = new_info
                        daddy[i.flight_no] = curr_flight

        # the route
        if last is None:
            return []
        else:
            route = [last]
            curr = last
            while daddy[curr.flight_no] is not None:
                route.append(daddy[curr.flight_no])
                curr = daddy[curr.flight_no]

            return list(reversed(route))


class Queue:
    def __init__(self):
        self.in_stack = []
        self.out_stack = []

    def enqueue(self, item):
        self.in_stack.append(item)

    def dequeue(self):
        if not self.out_stack:
            while self.in_stack:
                self.out_stack.append(self.in_stack.pop())
        
        if self.out_stack:
            return self.out_stack.pop()
        else:
            raise IndexError("dequeue from empty queue")

    def is_empty(self):
        return len(self.in_stack) == 0 and len(self.out_stack) == 0
    def _print(self):
        print(self.in_stack)

        

class Heap:
    '''
    Class to implement a heap with general comparison function.
    '''

    def __init__(self, comparison_function, init_array):
        '''
        Arguments:
            comparison_function : function : A function that takes in two arguments and returns a boolean value
            init_array : List[Any] : The initial array to be inserted into the heap
        Returns:
            None
        Description:
            Initializes a heap with a comparison function
        Time Complexity:
            O(n) where n is the number of elements in init_array
        '''
        self.heap_arr = init_array
        self.size = len(init_array)
        self.comparison_function = comparison_function

        # Heapify the initial array
        for i in range(self.size // 2, -1, -1):
            self._heapify_down(i)
        
    def insert(self, value):
        '''
        Arguments:
            value : Any : The value to be inserted into the heap
        Returns:
            None
        Description:
            Inserts a value into the heap
        Time Complexity:
            O(log(n)) where n is the number of elements currently in the heap
        '''
        self.size += 1
        self.heap_arr.append(value)
        self._heapify_up(self.size - 1)

    def extract(self):
        '''
        Arguments:
            None
        Returns:
            Any : The value extracted from the top of heap
        Description:
            Extracts the value from the top of heap, i.e. removes it from heap
        Time Complexity:
            O(log(n)) where n is the number of elements currently in the heap
        '''
        if self.size == 0:
            return None
        
        root = self.heap_arr[0]
        self.heap_arr[0] = self.heap_arr[self.size - 1]  # Move last element to the root
        self.heap_arr.pop()  # Remove last element
        self.size -= 1
        self._heapify_down(0)  # Restore heap property by heapifying down
        return root


   
    def _heapify_up(self, index):
        '''Heapify up to restore heap property after insertion.'''
        parent = (index - 1) // 2
        if index > 0 and not self.comparison_function(self.heap_arr[parent], self.heap_arr[index]):
            self.heap_arr[parent], self.heap_arr[index] = self.heap_arr[index], self.heap_arr[parent]
            self._heapify_up(parent)

    def _heapify_down(self, index):
        '''Heapify down to restore heap property after extraction.'''
        smallest = index
        left = 2 * index + 1
        right = 2 * index + 2

        if left < self.size and not self.comparison_function(self.heap_arr[smallest], self.heap_arr[left]):
            smallest = left

        if right < self.size and not self.comparison_function(self.heap_arr[smallest], self.heap_arr[right]):
            smallest = right

        if smallest != index:
            self.heap_arr[index], self.heap_arr[smallest] = self.heap_arr[smallest], self.heap_arr[index]
            self._heapify_down(smallest)



    def is_empty(self):
        '''
        Returns True if the heap is empty, otherwise False.
        '''
        return self.size == 0
    
    


# Comparison functions for different heap types







def fare(a, b):
    
    return a.fare < b.fare
def miya(a,b):
    return a[0]<b[0]




