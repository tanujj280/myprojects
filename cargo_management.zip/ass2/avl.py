from node import Node

def comp_1(node_1, node_2):
    pass
def comp_2(node_1, node_2):
    pass
def comp_3(node_1, node_2):
    pass
class AVLTree:
    def __init__(self, compare_function=comp_1):
        self.root = None
        self.size = 0
        self.comparator = compare_function
        self.ans=[]
        

   
    def _height(self, node):
        if not node:
            return 0
        return node.height

    def _update_height(self, node):
        if node:
            node.height = 1 + max(self._height(node.left), self._height(node.right))

    
    def _right_rotate(self, y):
        x = y.left
        T2 = x.right

      
        x.right = y
        y.left = T2

        
        self._update_height(y)
        self._update_height(x)

        return x

   
    def _left_rotate(self, x):
        y = x.right
        T2 = y.left

        
        y.left = x
        x.right = T2

        
        self._update_height(x)
        self._update_height(y)

        return y

   
    def _get_balance(self, node):
        if not node:
            return 0
        return self._height(node.left) - self._height(node.right)

    def _insert(self, node, key, value):
        
        if not node:
            self.size += 1
            return Node(key, value)

        if key < node.key:
            node.left = self._insert(node.left, key, value)
        elif key > node.key:
            node.right = self._insert(node.right, key, value)
        else:
            
            node.value = value
            return node

        
        self._update_height(node)

        
        balance = self._get_balance(node)


        # Left Left 
        if balance > 1 and key < node.left.key:
            return self._right_rotate(node)

        # Right Right 
        if balance < -1 and key > node.right.key:
            return self._left_rotate(node)

        # Left Right 
        if balance > 1 and key > node.left.key:
            node.left = self._left_rotate(node.left)
            return self._right_rotate(node)

        # Right Left
        if balance < -1 and key < node.right.key:
            node.right = self._right_rotate(node.right)
            return self._left_rotate(node)

        return node

    
    def insert(self, key, value):
        self.root = self._insert(self.root, key, value)

    
    def _min_value_node(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current

    
    def _remove(self, root, key):
        if not root:
            return root

       
        if key < root.key:
            root.left = self._remove(root.left, key)
        elif key > root.key:
            root.right = self._remove(root.right, key)
        else:
            #  one child or no child
            if not root.left:
                return root.right
            elif not root.right:
                return root.left

            
            temp = self._min_value_node(root.right)
            root.key = temp.key
            root.value = temp.value
            root.right = self._remove(root.right, temp.key)

       
        self._update_height(root)


        balance = self._get_balance(root)

        # Left Left 
        if balance > 1 and self._get_balance(root.left) >= 0:
            return self._right_rotate(root)

        # Left Right
        if balance > 1 and self._get_balance(root.left) < 0:
            root.left = self._left_rotate(root.left)
            return self._right_rotate(root)

        # Right Right
        if balance < -1 and self._get_balance(root.right) <= 0:
            return self._left_rotate(root)

        # Right Left
        if balance < -1 and self._get_balance(root.right) > 0:
            root.right = self._right_rotate(root.right)
            return self._left_rotate(root)

        return root
    
    def remove(self, key):
        self.root = self._remove(self.root, key)

    
    
    



    # Public method to remove a key-value pair from the AVL tree
    # def remove(self, key):
    #     self.root = self._remove(self.root, key)

    # Search for a node with a given key
    def search(self, key):
        return self._search(self.root, key)

    # Helper function to search for a key in the AVL tree
    def _search(self, node, key):
        if node is None or node.key == key:
            return node

        if key < node.key:
            return self._search(node.left, key)
        else:
            return self._search(node.right, key)

    # In-order traversal to print the key-value pairs in sorted order
    # def _in_order(self, node):
        
    #     if not node:
    #         return 
    #     self._in_order(node.left)
    #     # self.ans.append(node.key)
    #     # print(node.key, end=" ")
    #     l.append(node.key)
    #     # print(f"Key: {node.key}, Value: {node.value}")
    #     self._in_order(node.right)

    #     return self.ans

    # # Public method to print the AVL tree
    # def inorder(self):
        
    #     _in_order(self.root)
        # return l
        # print(f"Tree size: {self.size}")

    def inorder(self, root):
        result = []
        self._inorder_helper(root, result)
        return result

    def _inorder_helper(self, node, result):
        if not node:
            return
        self._inorder_helper(node.left, result)
        result.append(node.key)
        self._inorder_helper(node.right, result)